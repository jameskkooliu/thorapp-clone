import React from "react";

function ListSync() {
    return (
        <div className="main">ListSync</div>
    )
}
export default ListSync;