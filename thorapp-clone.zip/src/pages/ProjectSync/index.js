import React from "react";

function ProjectSync() {
    return (
        <div className="main">ProjectSync</div>
    )
}

export default ProjectSync;